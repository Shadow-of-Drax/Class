import React from "react";
import ReactDOM from "react-dom";

const fName = "James";
const lName = "Warren";

ReactDOM.render(
  <div>
    <h1>
      Hello {fName} {lName}!
    </h1>
    <p>Here are some random stats for you!</p>
    <ul>
      <li>Strength = {Math.floor(Math.random() * 20)}</li>
      <li>Dextarity = {Math.floor(Math.random() * 20)}</li>
      <li>Constitution = {Math.floor(Math.random() * 20)}</li>
      <li>Wisdom = {Math.floor(Math.random() * 20)}</li>
      <li>Intelligance = {Math.floor(Math.random() * 20)}</li>
      <li>Charisma = {Math.floor(Math.random() * 20)}</li>
    </ul>
  </div>,
  document.getElementById("root")
);
