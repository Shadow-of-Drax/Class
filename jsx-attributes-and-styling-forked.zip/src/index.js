import React from "react";
import ReactDOM from "react-dom";

ReactDOM.render(
  <div>
    <h1 className="heading">My Favourite Foods</h1>
    <div>
      <img src="https://thebakermama.com/wp-content/uploads/2018/08/fullsizeoutput_15a7c.jpg"></img>
      <img src="https://img.sndimg.com/food/image/upload/f_auto,c_thumb,q_55,w_744,ar_5:4/v1/img/recipes/23/63/67/piccbq0i7.jpg"></img>
      <img src="https://www.craftycookbook.com/wp-content/uploads/2023/04/tonkotsu.jpg"></img>
    </div>
  </div>,
  document.getElementById("root")
);
