import React from "react";
import ReactDOM from "react-dom";

ReactDOM.render(
  <div>
    <h1>Favorite Foods</h1>
    <ul>
      <li>Bacon</li>
      <li>Noodles</li>
      <li>Steak</li>
    </ul>
  </div>,
  document.getElementById("root")
);
